# Especificação para o Agente 3 (Refatoração)

> Use este documento como prompt/contexto para o agente de refatoração
> (Claude Code). Execute-o duas vezes, uma apontando para
> `multiagente/monolito` e outra para `multiagente/microservicos`, igual ao
> procedimento do Agente 1.

## Papel do agente

Você é o Agente 3 (refatoração) no pipeline multiagente. Sua tarefa é
corrigir **apenas** os achados reais reportados pelo Agente 2 (SpotBugs),
sem alterar nenhum outro comportamento, sem alterar os 12 cenários
funcionais (T01-T12) e sem introduzir novas dependências.

## Achados a corrigir (reais)

**Tipo:** `EI_EXPOSE_REP` / `EI_EXPOSE_REP2` (CWE-374) — a classe expõe ou
armazena uma referência direta a uma lista mutável, permitindo que código
externo altere o estado interno do objeto sem passar pelos construtores/
setters.

**Onde:** classe `PortfolioResponse` (é um `record` Java), no campo/
acessador `positions` (tipo `List<PositionView>`):

- `multiagente/monolito/src/main/java/com/tcc/finance/web/dto/PortfolioResponse.java`
- `multiagente/microservicos/trade-service/src/main/java/com/tcc/finance/trade/web/dto/PortfolioResponse.java`

**Correção esperada** (aplicar nos dois arquivos, de forma idêntica — são a
mesma classe duplicada nas duas arquiteturas):

1. No construtor compacto do record, normalizar `positions` para uma cópia
   imutável: `positions = positions == null ? List.of() : List.copyOf(positions);`
2. Sobrescrever o accessor `positions()` do record para devolver sempre uma
   cópia (`List.copyOf(positions)` ou `Collections.unmodifiableList(...)`),
   em vez do campo diretamente — isso garante que o SpotBugs não aponte o
   mesmo problema no retorno, mesmo já tendo sido copiado no construtor.

Não altere a assinatura pública do record (nomes/ordem dos componentes:
`username, positions, saldo, stocksValue, totalValue` ou equivalente — use
os nomes reais do arquivo).

## Achados a NÃO corrigir (falsos positivos documentados)

**Tipo:** mesmo `EI_EXPOSE_REP2`, mas em construtores que recebem **beans
gerenciados pelo Spring** via injeção de dependência:

- `TradeService.../trade-service/.../client/FeignErrorDecoder.java` —
  guarda `ObjectMapper` injetado no construtor.
- `TradeService.../trade-service/.../messaging/TradeEventPublisher.java` —
  guarda `RabbitTemplate` injetado no construtor.

Esses NÃO devem ser "corrigidos" (copiar um `ObjectMapper`/`RabbitTemplate`
não faz sentido — são singletons gerenciados pelo container Spring, não
dados mutáveis de domínio). Em vez disso:

- Adicione um comentário curto acima de cada construtor explicando que é um
  falso positivo do SpotBugs para beans injetados via Spring (ex.:
  `// SpotBugs EI_EXPOSE_REP2: falso positivo - bean gerenciado pelo Spring, nao estado mutavel de dominio`).
- Opcional, se o tempo permitir: suprimir formalmente com
  `@SuppressFBWarnings(value = "EI_EXPOSE_REP2", justification = "...")`
  da dependência `com.github.spotbugs:spotbugs-annotations` — só adicione
  essa dependência se não exigir resolver árvore de rede nova demorada;
  caso contrário, o comentário simples já é suficiente para o TCC.

## Critérios de aceitação

- Os 12 cenários (T01-T12) continuam passando nas duas arquiteturas
  (rodar os testes JUnit existentes, não criar novos).
- Build continua verde (`mvn clean package`) nos dois lados.
- Resultado esperado ao rodar o Agente 2 (SpotBugs) de novo: 0 achados em
  `PortfolioResponse` nas duas arquiteturas; os 2 achados em
  `FeignErrorDecoder`/`TradeEventPublisher` continuam aparecendo (são
  falsos positivos documentados, não erros) — registrar isso
  explicitamente no log, para não ser confundido com regressão.

## Registro do processo (para as métricas do TCC)

Salvar resumo em `metrics/agente3_<arquitetura>_log.md` com:
- arquivos alterados;
- diff aplicado (antes/depois) de `PortfolioResponse`;
- confirmação de que T01-T12 continuam passando;
- justificativa registrada para os 2 achados não corrigidos.
