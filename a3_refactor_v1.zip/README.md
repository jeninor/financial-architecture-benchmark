# A3 Refactor v1

A3 consumes the deterministic findings produced by A2/A4, edits a COPY of the
successful A1 workspace, re-runs the immutable acceptance gate, packages the
final JAR, and then measures quality/security again.

The original A1 workspace is never modified.

## Install

```bash
cp prompts/refactor.md multiagent-experiment/prompts/
cp scripts/run_a3_refactor_v1.py multiagent-experiment/scripts/
chmod +x multiagent-experiment/scripts/run_a3_refactor_v1.py
```

Prerequisites already created earlier:

```text
scripts/graphify_runtime_v4.py
scripts/run_a4_artifact_offline_v2.py
docker/quality/*
policies/quality_policy.json
policies/security_policy_v2.json
tool-cache/trivy/*
```

## P0007 pilot

Use the completed A4-v2 outputs:

```bash
python3 multiagent-experiment/scripts/run_a3_refactor_v1.py \
  --repo-root . \
  --framework-root multiagent-experiment \
  --source-run P0007_monolith \
  --model sonnet \
  --findings-json multiagent-experiment/runs/P0007_monolith/analysis_before_v2/findings.json \
  --quality-before multiagent-experiment/runs/P0007_monolith/analysis_before/quality_before.json \
  --security-before multiagent-experiment/runs/P0007_monolith/analysis_before_v2/security_before.json \
  --graphify-image graphify-mcp:0.9.73 \
  --graph-budget 1200 \
  --startup-timeout 360 \
  --max-turns-refactor 8 \
  --max-turns-repair 5 \
  --max-repair-attempts 1 \
  --lizard-image multiagent-lizard:1.24.0 \
  --trivy-image aquasec/trivy:0.74.0 \
  --trivy-cache multiagent-experiment/tool-cache/trivy \
  --quality-policy multiagent-experiment/policies/quality_policy.json \
  --security-policy multiagent-experiment/policies/security_policy_v2.json \
  2>&1 | tee multiagent-experiment/P0007_A3_console.log
```

## Outputs

```text
runs/P0007_monolith/a3/
├── workspace/                  # refactored copy; A1 original is untouched
├── a3_config.json
├── graphify_before/
├── graph_query.txt
├── graph_context.txt
├── attempt_01/
│   ├── claude_trace.jsonl
│   ├── claude_usage.json
│   ├── acceptance.json
│   └── artifacts.json
├── analysis_after/
│   ├── quality_after.json
│   ├── security_after.json
│   ├── findings_after.json
│   └── A2_A4_AFTER_REPORT.md
├── before_after.json
├── a3_summary.json
└── A3_REPORT.md
```

## Experimental rules encoded

- A3 sees the public requirements/contracts and deterministic findings.
- A3 does **not** receive external acceptance-test source.
- A3 has no Bash/Docker/Maven tools; lifecycle is orchestrator-owned.
- Graphify retrieval is orchestrator-controlled.
- If there are zero findings, A3 is skipped without an LLM call.
- At most one repair attempt is allowed by default.
- A3 edits a copy, preserving the before implementation.
- A2/A4 after-measurement happens only after 12/12 acceptance.
