# A1 Graphify v4 — Docker context/image preflight

Este patch trata o problema recorrente em que:

```text
docker image ls
```

mostra `graphify-mcp:0.9.73`, mas:

```text
docker image inspect graphify-mcp:0.9.73
```

retorna `not found`.

## Política

O experimento deve usar **um único Docker context**. Não é seguro alternar
automaticamente para outro daemon, porque Compose e Graphify poderiam rodar
em ambientes diferentes.

O preflight agora:

1. identifica o Docker context atual;
2. tenta resolver a tag normalmente;
3. se `inspect(tag)` falhar mas `image ls` mostrar a tag, tenta resolver pelo
   **image ID imutável**;
4. apenas para diagnóstico, procura a tag nos outros contexts;
5. nunca muda de context silenciosamente;
6. o runner usa o image ID resolvido nas chamadas `docker run`.

## Instalação

```bash
cp scripts/graphify_runtime_v4.py multiagent-experiment/scripts/
cp scripts/run_a1_graphify_v4.py multiagent-experiment/scripts/
cp scripts/preflight_graphify.py multiagent-experiment/scripts/

chmod +x multiagent-experiment/scripts/run_a1_graphify_v4.py
chmod +x multiagent-experiment/scripts/preflight_graphify.py
```

## Diagnóstico sem gastar tokens

```bash
python3 multiagent-experiment/scripts/preflight_graphify.py   --image graphify-mcp:0.9.73
```

## P0007

Se o preflight terminar em `RESULT: OK`:

```bash
python3 multiagent-experiment/scripts/run_a1_graphify_v4.py   --repo-root .   --framework-root multiagent-experiment   --prefix P   --seq 7   --model sonnet   --graphify-image graphify-mcp:0.9.73   --graph-budget 1200   --startup-timeout 360   2>&1 | tee multiagent-experiment/P0007_graphify_console.log
```
