#!/usr/bin/env bash
# Agente 4 (seguranca) - roda Trivy sobre monolito e microservicos
# e salva resultados em JSON para a coleta de metricas do TCC.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
METRICS_DIR="$ROOT_DIR/metrics"
mkdir -p "$METRICS_DIR"

TIMESTAMP="$(date +%Y%m%d_%H%M%S)"

echo "== Trivy: multiagente/monolito =="
docker run --rm \
  -v "$ROOT_DIR/multiagente/monolito:/app" \
  aquasec/trivy fs --format json --output /app/.trivy_out.json /app || true
mv "$ROOT_DIR/multiagente/monolito/.trivy_out.json" \
   "$METRICS_DIR/trivy_monolito_${TIMESTAMP}.json" 2>/dev/null || \
   echo "Aviso: nenhum arquivo de saida gerado para o monolito"

echo "== Trivy: multiagente/microservicos =="
docker run --rm \
  -v "$ROOT_DIR/multiagente/microservicos:/app" \
  aquasec/trivy fs --format json --output /app/.trivy_out.json /app || true
mv "$ROOT_DIR/multiagente/microservicos/.trivy_out.json" \
   "$METRICS_DIR/trivy_microservicos_${TIMESTAMP}.json" 2>/dev/null || \
   echo "Aviso: nenhum arquivo de saida gerado para os microservicos"

echo "Resultados salvos em $METRICS_DIR"
