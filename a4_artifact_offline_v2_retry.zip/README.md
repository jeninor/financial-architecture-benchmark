# A4 Artifact Offline v2

Fix for Maven Central HTTP 429 during Trivy Java scanning.

## Why v1 failed

A vulnerability scan over the complete source workspace includes `pom.xml`.
Trivy then resolves Maven dependency metadata. If required POMs are not in the
local Maven repository, it may contact Maven Central and be rate-limited.

## v2 measurement design

A4 is split into two deterministic/offline scans:

1. **Source workspace**
   - scanners: `secret,misconfig`
   - no dependency resolution needed.

2. **Built JAR artifact(s)**
   - scanner: `vuln`
   - scans the actual packaged dependencies embedded in the JAR.
   - no Maven Central dependency-tree resolution.

All Trivy containers use:

```text
--network none
--offline-scan
--skip-db-update
--skip-java-db-update
--skip-check-update
--skip-version-check
```

This ensures an accidental remote Maven request is impossible.

The runner deliberately fails with `A4_ARTIFACT_MISSING` if no `target/*.jar`
exists. It never silently falls back to online POM scanning.

## Install

```bash
cp scripts/run_a4_artifact_offline_v2.py \
  multiagent-experiment/scripts/

cp policies/security_policy_v2.json \
  multiagent-experiment/policies/

chmod +x multiagent-experiment/scripts/run_a4_artifact_offline_v2.py
```

## Check P0007 artifact first

```bash
find multiagent-experiment/runs/P0007_monolith/workspace \
  -type f -path '*/target/*.jar' -printf '%p %s bytes\n'
```

## Run

Keep the failed `analysis_before/` as pilot evidence. Write v2 into a new
directory:

```bash
python3 multiagent-experiment/scripts/run_a4_artifact_offline_v2.py \
  --workspace multiagent-experiment/runs/P0007_monolith/workspace \
  --quality-json multiagent-experiment/runs/P0007_monolith/analysis_before/quality_before.json \
  --output-dir multiagent-experiment/runs/P0007_monolith/analysis_before_v2 \
  --trivy-image aquasec/trivy:0.74.0 \
  --trivy-cache multiagent-experiment/tool-cache/trivy \
  --security-policy multiagent-experiment/policies/security_policy_v2.json \
  2>&1 | tee multiagent-experiment/P0007_A4_v2_console.log
```

## If no JAR exists

Do not run Trivy against `pom.xml` online. For this pilot, package the current
workspace first using the same frozen Compose/Maven environment, then rerun A4.

For official runs, the A1 orchestrator should package and hash application JARs
immediately after the 12/12 acceptance gate and before Docker cleanup.
