# A1 Builder Pilot v1

Executa apenas:

`baseline monolítico -> Claude A1 -> Docker -> suite black-box externa -> loop`

Use prefixo `P` para piloto. O piloto não entra na amostra estatística final.

## Instalação

Copie `scripts/run_a1_builder.py` para
`multiagent-experiment/scripts/run_a1_builder.py`.

## Antes de executar

Desligue qualquer implementação legacy que use a porta 8080.

## Exemplo

O smoke test atual identificou `claude-opus-5-5` como modelo canônico. Para
congelar explicitamente esse mesmo modelo:

```bash
python3 multiagent-experiment/scripts/run_a1_builder.py   --repo-root .   --framework-root multiagent-experiment   --prefix P   --seq 1   --model claude-opus-5-5
```

A execução cria `multiagent-experiment/runs/P0001_monolith/`.

O script registra hashes do acceptance runner/contract, versão do Claude,
custos/tokens reportados pela CLI, iterações, logs Docker e resultado 12/12.
