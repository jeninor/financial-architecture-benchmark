# Microservices pilot v1

This package extends the already validated monolith pilot to the
**microservices** architecture while preserving the same public API, Claude
model, acceptance suite, Graphify budget, A2 thresholds and A4 policy.

It does not use or modify `tcc-financeiro/multiagente`.

## Included

```text
contracts/architecture_microservices.md
prompts/builder_microservices.md
prompts/refactor_microservices.md
scripts/preflight_microservices.py
scripts/run_a1_microservices_v1.py
scripts/run_a3_microservices_v1.py
```

Prerequisites already present from the monolith work:

```text
scripts/graphify_runtime_v4.py
scripts/run_a2_a4.py
scripts/run_a4_artifact_offline_v2.py
docker/quality/*
policies/quality_policy.json
policies/security_policy_v2.json
tool-cache/trivy/*
acceptance-tests/*
contracts/public_api_v1.md
contracts/requirements.md
baselines/microservices/
```

## 1. Install

From the repository root:

```bash
mkdir -p /tmp/micro-v1
unzip -o microservices_pilot_v1.zip -d /tmp/micro-v1

cp /tmp/micro-v1/contracts/architecture_microservices.md \
  multiagent-experiment/contracts/

cp /tmp/micro-v1/prompts/builder_microservices.md \
  multiagent-experiment/prompts/

cp /tmp/micro-v1/prompts/refactor_microservices.md \
  multiagent-experiment/prompts/

cp /tmp/micro-v1/scripts/preflight_microservices.py \
  multiagent-experiment/scripts/

cp /tmp/micro-v1/scripts/run_a1_microservices_v1.py \
  multiagent-experiment/scripts/

cp /tmp/micro-v1/scripts/run_a3_microservices_v1.py \
  multiagent-experiment/scripts/

cp /tmp/micro-v1/scripts/run_a2_only.py \
  multiagent-experiment/scripts/

chmod +x multiagent-experiment/scripts/preflight_microservices.py
chmod +x multiagent-experiment/scripts/run_a1_microservices_v1.py
chmod +x multiagent-experiment/scripts/run_a3_microservices_v1.py
chmod +x multiagent-experiment/scripts/run_a2_only.py
```

## 2. Preflight — no Claude tokens

```bash
python3 multiagent-experiment/scripts/preflight_microservices.py \
  --repo-root . \
  --framework-root multiagent-experiment \
  --graphify-image graphify-mcp:0.9.73 \
  --lizard-image multiagent-lizard:1.24.0 \
  --trivy-image aquasec/trivy:0.74.0
```

Expected baseline characteristics:

- frozen microservices `docker-compose.yml`;
- five Spring Boot application skeletons;
- no business Java implementation in the baseline;
- application roles:
  `discovery-server`, `api-gateway`, `user-service`, `market-service`,
  `trade-service`.

The Compose file remains the canonical source for the complete infrastructure
topology.

## 3. A1 microservices pilot — P0008

```bash
python3 multiagent-experiment/scripts/run_a1_microservices_v1.py \
  --repo-root . \
  --framework-root multiagent-experiment \
  --prefix P \
  --seq 8 \
  --model sonnet \
  --graphify-image graphify-mcp:0.9.73 \
  --graph-budget 1200 \
  --startup-timeout 360 \
  --max-iterations 3 \
  --max-turns-first 15 \
  --max-turns-fix 8 \
  2>&1 | tee multiagent-experiment/P0008_microservices_console.log
```

Important v1 change relative to the old monolith pilot: Graphify extraction is
performed **after a failure**, against the code that actually failed. It is not
wasted on the nearly empty baseline before the first Claude call.

On a successful 12/12 gate, the orchestrator packages all application service
JARs and records their SHA256 hashes for A4.

## 4. A2 + A4 before A3

Only after P0008 succeeds, run A2 without invoking the old online Trivy path:

```bash
python3 multiagent-experiment/scripts/run_a2_only.py \
  --workspace multiagent-experiment/runs/P0008_microservices/workspace \
  --output-dir multiagent-experiment/runs/P0008_microservices/analysis_before \
  --lizard-image multiagent-lizard:1.24.0 \
  --quality-policy multiagent-experiment/policies/quality_policy.json
```

Then run the already validated offline artifact A4:

```bash
python3 multiagent-experiment/scripts/run_a4_artifact_offline_v2.py \
  --workspace multiagent-experiment/runs/P0008_microservices/workspace \
  --quality-json multiagent-experiment/runs/P0008_microservices/analysis_before/quality_before.json \
  --output-dir multiagent-experiment/runs/P0008_microservices/analysis_before_v2 \
  --trivy-image aquasec/trivy:0.74.0 \
  --trivy-cache multiagent-experiment/tool-cache/trivy \
  --security-policy multiagent-experiment/policies/security_policy_v2.json
```

This cleanly avoids the Maven Central resolution path that caused HTTP 429 in
the monolith pilot.

## 5. A3 microservices

After deterministic findings exist:

```bash
python3 multiagent-experiment/scripts/run_a3_microservices_v1.py \
  --repo-root . \
  --framework-root multiagent-experiment \
  --source-run P0008_microservices \
  --model sonnet \
  --findings-json multiagent-experiment/runs/P0008_microservices/analysis_before_v2/findings.json \
  --quality-before multiagent-experiment/runs/P0008_microservices/analysis_before/quality_before.json \
  --security-before multiagent-experiment/runs/P0008_microservices/analysis_before_v2/security_before.json \
  --graphify-image graphify-mcp:0.9.73 \
  --graph-budget 1200 \
  --startup-timeout 360 \
  --max-turns-refactor 8 \
  --max-turns-repair 5 \
  --max-repair-attempts 1 \
  --lizard-image multiagent-lizard:1.24.0 \
  --trivy-image aquasec/trivy:0.74.0 \
  --trivy-cache multiagent-experiment/tool-cache/trivy \
  --quality-policy multiagent-experiment/policies/quality_policy.json \
  --security-policy multiagent-experiment/policies/security_policy_v2.json \
  2>&1 | tee multiagent-experiment/P0008_A3_console.log
```

## Methodological note

P0008 remains a **pilot**, not an official replicate. After the microservices
pipeline is stable, create one architecture-parameterized official runner so
monolith and microservices use the same orchestration logic. This avoids a
runner-version confound in the final experiment.
