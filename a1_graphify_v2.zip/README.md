# A1 Graphify v2

Correções após P0003:

- Graphify passa a ser usado pelo ORQUESTRADOR para recuperar contexto após
  falhas funcionais, em vez de depender de Claude escolher ferramentas MCP.
- Claude não deve executar `docker compose up/down/start/stop/restart`;
  o ciclo de containers pertence ao orquestrador.
- `total_cost_usd` de uma sessão retomada é tratado como cumulativo.
  O relatório não soma valores cumulativos repetidamente.
- Mantém grafo local `--code-only`, sem rede e sem API.
- `graphify query` usa budget padrão de 1200 tokens.

Use um novo piloto; não sobrescreva P0003.
