# A2 Quality + A4 Security v1

Deterministic agents for the finance-architecture experiment.

- **A2 Quality:** Lizard `1.24.0`
- **A4 Security:** Trivy `0.74.0`
- Neither agent calls an LLM.

The current Trivy release was frozen to 0.74.0. The security database is
downloaded once and subsequent experiment scans use the same cached snapshot.

## Install

From the repository root:

```bash
mkdir -p multiagent-experiment/docker/quality
mkdir -p multiagent-experiment/policies

cp docker/quality/Dockerfile multiagent-experiment/docker/quality/
cp docker/quality/quality_analyzer.py multiagent-experiment/docker/quality/

cp scripts/run_a2_a4.py multiagent-experiment/scripts/
cp scripts/prepare_a2_a4_tools.sh multiagent-experiment/scripts/
cp scripts/freeze_trivy_cache_manifest.py multiagent-experiment/scripts/

cp policies/quality_policy.json multiagent-experiment/policies/
cp policies/security_policy.json multiagent-experiment/policies/

chmod +x multiagent-experiment/scripts/run_a2_a4.py
chmod +x multiagent-experiment/scripts/prepare_a2_a4_tools.sh
chmod +x multiagent-experiment/scripts/freeze_trivy_cache_manifest.py
```

## Prepare once

This is the only step that intentionally downloads Trivy databases:

```bash
multiagent-experiment/scripts/prepare_a2_a4_tools.sh \
  /home/alunos/Documentos/Juan/usp/financial-architecture-benchmark
```

Then freeze the local DB snapshot manifest:

```bash
python3 multiagent-experiment/scripts/freeze_trivy_cache_manifest.py \
  --cache multiagent-experiment/tool-cache/trivy \
  --output multiagent-experiment/tool-cache/TRIVY_CACHE_MANIFEST.json
```

Do **not** refresh this cache between monolith and microservices official runs.

## Pilot over P0007

```bash
python3 multiagent-experiment/scripts/run_a2_a4.py \
  --workspace multiagent-experiment/runs/P0007_monolith/workspace \
  --output-dir multiagent-experiment/runs/P0007_monolith/analysis_before \
  --lizard-image multiagent-lizard:1.24.0 \
  --trivy-image aquasec/trivy:0.74.0 \
  --trivy-cache multiagent-experiment/tool-cache/trivy \
  --quality-policy multiagent-experiment/policies/quality_policy.json \
  --security-policy multiagent-experiment/policies/security_policy.json \
  2>&1 | tee multiagent-experiment/P0007_A2_A4_console.log
```

Outputs:

```text
analysis_before/
├── quality_before.json
├── security_before.json
├── trivy_raw.json
├── findings.json
├── analysis_manifest.json
└── A2_A4_REPORT.md
```

## A2 metrics

Production scope is only `src/main/java/**/*.java`.

- physical Java LOC
- nonblank Java LOC
- Java file count
- Lizard NLOC
- functions/methods
- CC total / average / max
- top complex functions
- policy findings

Frozen candidate thresholds:

```text
function CCN > 10
function NLOC > 60
file NLOC > 300
parameters > 6
```

## A4 policy

```text
scanners  = vuln,secret,misconfig
severity  = HIGH,CRITICAL
```

The runner uses:

```text
--skip-db-update
--skip-java-db-update
--skip-check-update
```

to preserve the measurement snapshot.

`security_before.json` is sanitized and does not copy secret values. The full
local Trivy output is retained in `trivy_raw.json` for auditability.
