# A1 Builder Live v3

Versão do piloto com saída ao vivo.

## O que aparece no terminal

- início/fim de cada iteração;
- eventos resumidos do Claude;
- ferramentas chamadas pelo Claude;
- build/start Docker;
- readiness HTTP;
- saída completa dos 12 testes de aceitação;
- preparação de feedback;
- cleanup final.

O trace bruto do Claude é preservado como `claude_trace.jsonl`.

## Instalação

```bash
cp scripts/run_a1_builder_live.py   multiagent-experiment/scripts/
```

## Exemplo

```bash
python3 multiagent-experiment/scripts/run_a1_builder_live.py   --repo-root .   --framework-root multiagent-experiment   --prefix P   --seq 3   --model claude-opus-5-5   2>&1 | tee multiagent-experiment/runs/P0003_console.log
```

Use um novo `--seq`; nunca sobrescreva P0001/P0002.

Ao final também é criado `RUN_REPORT.md`.
