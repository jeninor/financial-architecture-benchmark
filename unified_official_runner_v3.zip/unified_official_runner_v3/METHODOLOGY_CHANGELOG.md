# Harness methodology change — v2 to v3

R0002_microservices produced independent dependency failures while the generated application services had not started: RabbitMQ exited during A1 iteration 1 and user-postgres was unhealthy during iteration 3. The v2 runner captured only application-service logs and consumed Claude iterations before verifying those dependencies.

Protocol v3 changes only the orchestration/measurement harness. It does not change the functional contract, architecture contract, immutable acceptance suite, Claude model, Claude turn budgets, deterministic quality/security policies, or Graphify budget.

Primary-analysis rule: runs terminated because an independent infrastructure dependency cannot be stabilized are marked `ABORTED_INFRASTRUCTURE` and excluded from the primary architecture comparison. Genuine application build/start/acceptance failures occurring after infrastructure has been verified healthy remain valid experimental outcomes.
