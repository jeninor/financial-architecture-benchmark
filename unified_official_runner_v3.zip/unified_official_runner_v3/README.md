# Unified official runner v3

This revision hardens the experimental harness after R0002_microservices exposed independent Docker dependency failures.

## v3 changes

- Verifies Postgres/RabbitMQ infrastructure **before every Claude call**.
- Infrastructure retries do **not** consume Claude iterations or reported Claude cost.
- Keeps verified infrastructure running through the Claude call, then starts application services.
- If independent infrastructure fails during application startup, retries the **same generated code** without another Claude call.
- Captures logs and Docker health state for **all** Compose services, including RabbitMQ and both PostgreSQL containers.
- Requires key gateway routes to be reachable without 502/503 for 3 consecutive polls before acceptance. This is readiness only; any other HTTP status is left for the immutable acceptance suite to judge.
- Does not run Graphify after the final A1 iteration when no later repair call exists.
- Emits `ABORTED_INFRASTRUCTURE` separately from `VALID_AGENT_FAILURE`.
- Fixes `run_config.protocol_sha256` so it hashes the actual protocol file selected with `--protocol`.

The application contracts, acceptance suite, Claude model/turn limits, A2 policy, A4 policy, Graphify image/budget, and architecture baselines are unchanged.

R0001_monolith and R0002_microservices should remain preserved as historical/aborted evidence. Start the v3 paired series with a new sequence number after freezing `environment_lock_v3.json`.
