# A1 Graphify v3 — startup/readiness fix

Motivado pelo P0006.

Correções principais:

- `compose logs` é capturado **depois** da espera de readiness, não imediatamente
  após `docker compose up`.
- timeout de startup configurável (`--startup-timeout`, padrão 360 s).
- volumes são removidos apenas na primeira iteração do run; entre iterações o
  harness preserva volumes, reduzindo o risco de destruir um eventual cache
  Maven definido pelo Compose.
- salva separadamente:
  - `app_logs_after_wait.txt`
  - `compose_logs_after_wait.txt`
  - `compose_ps_after_wait.txt`
- startup failure com stack trace/erro real gera consulta Graphify e feedback.
- startup timeout sem evidência de erro **não consome outra chamada Claude**;
  termina como `STARTUP_TIMEOUT_NO_ERROR_EVIDENCE`.
- `builder_summary.json` e `RUN_REPORT.md` registram `termination_reason`.

Exemplo de próximo piloto:

```bash
python3 multiagent-experiment/scripts/run_a1_graphify_v3.py   --repo-root .   --framework-root multiagent-experiment   --prefix P   --seq 7   --model sonnet   --graphify-image graphify-mcp:0.9.73   --graph-budget 1200   --startup-timeout 360   2>&1 | tee multiagent-experiment/P0007_graphify_console.log
```

Não sobrescreva P0004/P0005/P0006.
