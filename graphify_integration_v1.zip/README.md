# Graphify integration v1

Integra Graphify ao A1 Builder sem `sudo`, usando apenas Docker.

## Decisões experimentais

- Graphify `0.9.73` é fixado na imagem.
- Extração `--code-only`: AST local/determinística, sem API/LLM.
- Workspace montado `:ro` durante a extração e durante o MCP.
- Rede desabilitada nos containers Graphify.
- Um grafo novo é gerado para cada iteração de cada run.
- O grafo fica em `runs/<run>/iteration_XX/graphify`, fora do workspace.
- Claude recebe o grafo por MCP somente leitura.
- O código-fonte continua sendo a autoridade final.
- A1 é instruído a consultar Graphify antes de exploração ampla com Glob/Grep/Read.
- O runner registra chamadas MCP Graphify, tokens, cache e custo reportado.

## Instalação

Da raiz do repositório:

```bash
cp docker/Dockerfile.graphify multiagent-experiment/docker/
cp scripts/graphify_runtime.py multiagent-experiment/scripts/
cp scripts/run_a1_graphify.py multiagent-experiment/scripts/
cp scripts/build_graphify_image.sh multiagent-experiment/scripts/

chmod +x multiagent-experiment/scripts/build_graphify_image.sh
chmod +x multiagent-experiment/scripts/run_a1_graphify.py
```

## Construir a imagem uma única vez

```bash
multiagent-experiment/scripts/build_graphify_image.sh
```

A imagem padrão será:

```text
graphify-mcp:0.9.73
```

## Smoke test manual

```bash
docker run --rm graphify-mcp:0.9.73 graphify --help
```

## Primeiro piloto Graphify

Não apague P0001/P0002.

```bash
python3 multiagent-experiment/scripts/run_a1_graphify.py \
  --repo-root . \
  --framework-root multiagent-experiment \
  --prefix P \
  --seq 3 \
  --model claude-opus-5-5 \
  --graphify-image graphify-mcp:0.9.73 \
  2>&1 | tee multiagent-experiment/P0003_graphify_console.log
```

O runner limita o piloto a 3 loops, 15 turns na primeira chamada e 8 nos fixes.

## Evidência gerada

Cada iteração grava:

```text
graphify/
  extract.log
  graphify-out/graph.json
  graph_metrics.json
mcp_graphify.json
graphify_tool_usage.json
claude_trace.jsonl
claude_usage.json
acceptance.json
```

## Comparação piloto

P0002 = A1 sem Graphify.
P0003 = A1 com Graphify.

A comparação é descritiva, não inferencial, pois execuções de LLM são
estocásticas. Antes dos runs oficiais, congele Graphify/modelo/limites.
