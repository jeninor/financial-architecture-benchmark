#!/usr/bin/env python3
"""
Patch helper for multiagent-experiment/scripts/run_a1_builder.py

Changes:
1. Require architecture_monolith.md and public_api_v1.md.
2. Add both documents to the A1 prompt.
3. Compare Docker Compose service membership as sets, not list order.
4. Persist raw/sorted service lists for diagnostics.
"""
from pathlib import Path
import sys

p = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "multiagent-experiment/scripts/run_a1_builder.py"
)

text = p.read_text(encoding="utf-8")
original = text

# 1) Add contract paths after prompt_file definition.
needle = '    prompt_file = fw / "prompts" / "builder.md"\n'
replacement = needle + (
    '    architecture_contract = fw / "contracts" / "architecture_monolith.md"\n'
    '    public_api_contract = fw / "contracts" / "public_api_v1.md"\n'
)
if needle not in text:
    raise SystemExit("Could not find prompt_file definition; patch not applied.")
text = text.replace(needle, replacement, 1)

# 2) Add to required list.
needle = '        acceptance_runner, acceptance_contract, requirements, prompt_file\n'
replacement = (
    '        acceptance_runner, acceptance_contract, requirements, prompt_file,\n'
    '        architecture_contract, public_api_contract\n'
)
if needle not in text:
    raise SystemExit("Could not find required-list line; patch not applied.")
text = text.replace(needle, replacement, 1)

# 3) Add contracts to static prompt.
needle = (
    '        + "\\n\\n# FIXED FUNCTIONAL CONTRACT\\n\\n"\n'
    '        + requirements.read_text(encoding="utf-8")\n'
)
replacement = (
    '        + "\\n\\n# FIXED ARCHITECTURE CONTRACT\\n\\n"\n'
    '        + architecture_contract.read_text(encoding="utf-8")\n'
    '        + "\\n\\n# PUBLIC API CONTRACT\\n\\n"\n'
    '        + public_api_contract.read_text(encoding="utf-8")\n'
    '        + "\\n\\n# FIXED FUNCTIONAL CONTRACT\\n\\n"\n'
    '        + requirements.read_text(encoding="utf-8")\n'
)
if needle not in text:
    raise SystemExit("Could not find static-prompt contract block; patch not applied.")
text = text.replace(needle, replacement, 1)

# 4) Replace order-sensitive service guard.
needle = (
    '            if compose_services(workspace) != baseline_services:\n'
    '                raise RuntimeError("ARCHITECTURE_VIOLATION: compose service list changed.")\n'
)
replacement = (
    '            current_services = compose_services(workspace)\n'
    '            service_guard = {\n'
    '                "baseline_raw": baseline_services,\n'
    '                "current_raw": current_services,\n'
    '                "baseline_sorted": sorted(set(baseline_services)),\n'
    '                "current_sorted": sorted(set(current_services)),\n'
    '            }\n'
    '            save_json(iter_dir / "architecture_guard.json", service_guard)\n'
    '            if set(current_services) != set(baseline_services):\n'
    '                raise RuntimeError(\n'
    '                    "ARCHITECTURE_VIOLATION: compose service membership changed: "\n'
    '                    + repr(service_guard)\n'
    '                )\n'
)
if needle not in text:
    raise SystemExit("Could not find compose-service guard; patch not applied.")
text = text.replace(needle, replacement, 1)

backup = p.with_suffix(p.suffix + ".v1.bak")
backup.write_text(original, encoding="utf-8")
p.write_text(text, encoding="utf-8")

print(f"[OK] Patched: {p}")
print(f"[OK] Backup : {backup}")
