# A1 Builder v2 patch

Este patch corrige dois pontos encontrados no piloto P0001:

1. O agente passa a receber explicitamente o contrato arquitetural e o contrato
   público da API.
2. A proteção de serviços Docker passa a comparar o CONJUNTO de serviços,
   não a ordem textual retornada por `docker compose config --services`.

## Instalação

Da raiz do repositório:

```bash
cp contracts/architecture_monolith.md multiagent-experiment/contracts/
cp contracts/public_api_v1.md multiagent-experiment/contracts/

python3 scripts/patch_run_a1_builder_v2.py   multiagent-experiment/scripts/run_a1_builder.py
```

Não apague `P0001_monolith`; ele é evidência de depuração do harness.
Use `P0002_monolith` para o próximo piloto.
