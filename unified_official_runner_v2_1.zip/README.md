# Unified Official Runner v2

Single experimental entry point for both architecture arms:

```text
run_experiment.py
├── --architecture monolith
└── --architecture microservices
```

The optional `run_experiment.sh` is only a convenience wrapper. It contains no
experimental logic.

## Why this runner exists

The pilots used several Python runners and shell helpers while the protocol was
being debugged. The official experiment should not compare a monolith produced
by one orchestration implementation against microservices produced by another.

This package therefore moves the complete official sequence into one Python
orchestrator:

```text
environment/preflight
        ↓
clean architecture baseline
        ↓
A1 Builder
        ↓
build/start/readiness
        ↓
immutable acceptance T01–T12
        ↓
package + JAR SHA256
        ↓
A2 Lizard
        ↓
A4 Trivy offline
        ↓
findings.json
        ↓
A3 Refactor (only when findings > 0)
        ↓
acceptance again
        ↓
package + A2/A4 after
        ↓
FINAL_SUMMARY.json
```

The same functions, limits, acceptance suite and measurement code are used for
both architectures. Architecture-specific differences live only in a small
configuration mapping: baseline, architecture contract, prompt and application
service list.

## Existing shell helpers are still supported

The earlier `.sh` files are not discarded.

`run_experiment.py` automatically uses environment/bootstrap helpers when
needed:

- `build_graphify_image.sh` if the Graphify image is missing.
- `prepare_a2_a4_tools.sh` only if a Trivy cache must be initialized from
  scratch.
- `freeze_trivy_cache_manifest.py` to freeze the existing Trivy snapshot.

Lizard is built directly with Docker when missing and Trivy is pulled directly
when missing. This avoids refreshing the frozen security database merely
because one tool image disappeared.

The shell scripts are infrastructure helpers, **not separate experimental
runners**.

## Cache policy

The unified runner treats state and dependency cache differently:

- database / broker state: clean for every A1/A3 attempt;
- Maven `/root/.m2` named volumes: preserved.

The runner reads the Compose configuration, detects volume mounts whose target
is `/root/.m2`, preserves those volumes, and removes the other named volumes.
This avoids the earlier `down -v` problem that destroyed Maven cache together
with experimental state.

## Installation

From the repository root:

```bash
cd /home/alunos/Documentos/Juan/usp/financial-architecture-benchmark

mkdir -p /tmp/unified-official-v1
unzip -o unified_official_runner_v1.zip -d /tmp/unified-official-v1

mkdir -p multiagent-experiment/protocol

cp /tmp/unified-official-v1/scripts/run_experiment.py \
  multiagent-experiment/scripts/

cp /tmp/unified-official-v1/scripts/run_experiment.sh \
  multiagent-experiment/scripts/

cp /tmp/unified-official-v1/protocol/official_protocol_v2.json \
  multiagent-experiment/protocol/

chmod +x multiagent-experiment/scripts/run_experiment.py
chmod +x multiagent-experiment/scripts/run_experiment.sh
```

Prerequisites from the completed pilots must remain available:

```text
multiagent-experiment/scripts/graphify_runtime_v4.py
multiagent-experiment/scripts/build_graphify_image.sh
multiagent-experiment/scripts/run_a4_artifact_offline_v2.py
multiagent-experiment/scripts/prepare_a2_a4_tools.sh
multiagent-experiment/scripts/freeze_trivy_cache_manifest.py

multiagent-experiment/docker/quality/*
multiagent-experiment/policies/quality_policy.json
multiagent-experiment/policies/security_policy_v2.json

multiagent-experiment/contracts/public_api_v1.md
multiagent-experiment/contracts/requirements.md
multiagent-experiment/contracts/architecture_monolith.md
multiagent-experiment/contracts/architecture_microservices.md

multiagent-experiment/prompts/builder.md
multiagent-experiment/prompts/builder_microservices.md
multiagent-experiment/prompts/refactor.md
multiagent-experiment/prompts/refactor_microservices.md

multiagent-experiment/baselines/monolith/
multiagent-experiment/baselines/microservices/
multiagent-experiment/acceptance-tests/
```

## Step 1 — prepare and lock the environment (NO Claude)

First try:

```bash
python3 multiagent-experiment/scripts/run_experiment.py \
  --architecture both \
  --prepare-only \
  --write-lock
```

This:

- checks Docker Desktop/current context;
- automatically restores missing Graphify/Lizard/Trivy images;
- validates both architecture baselines;
- validates Claude Code version;
- requires the frozen Trivy cache manifest;
- writes `multiagent-experiment/protocol/environment_lock_v2.json`.

It **does not call Claude**.

### If the Trivy cache exists but the manifest was never frozen

Use once:

```bash
python3 multiagent-experiment/scripts/run_experiment.py \
  --architecture both \
  --prepare-only \
  --initialize-security-cache \
  --write-lock
```

If cache files already exist, this command freezes the existing snapshot
without refreshing it. `prepare_a2_a4_tools.sh` is called only if the cache is
actually empty.

After this step, do not refresh the Trivy database during official runs.

## Step 2 — official paired replicate R0001

Monolith:

```bash
python3 multiagent-experiment/scripts/run_experiment.py \
  --architecture monolith \
  --seq 1
```

Microservices:

```bash
python3 multiagent-experiment/scripts/run_experiment.py \
  --architecture microservices \
  --seq 1
```

The directories are:

```text
multiagent-experiment/runs/R0001_monolith/
multiagent-experiment/runs/R0001_microservices/
```

The runner refuses to overwrite an existing official run.

## Optional shell entry point

Exactly the same experiment can be launched with:

```bash
multiagent-experiment/scripts/run_experiment.sh \
  --architecture monolith \
  --seq 1
```

The `.sh` simply executes the Python file and forwards all arguments.

For methodological documentation, describe `run_experiment.py` as the official
orchestrator.

## Pairing

Recommended sequence:

```text
R0001_monolith
R0001_microservices

R0002_monolith
R0002_microservices

R0003_monolith
R0003_microservices
...
```

Do not modify protocol files or the environment lock between the two
architecture arms of a pair.

## Frozen v1 protocol

The supplied protocol file currently fixes:

```text
Claude model        claude-sonnet-5-5
Claude Code         2.1.286 prefix
Graphify            graphify-mcp:0.9.73
Graphify budget     1200
Lizard image        multiagent-lizard:1.24.0
Trivy image         aquasec/trivy:0.74.0
Startup timeout     360 s

A1 max iterations   3
A1 first turns      15
A1 repair turns     8

A3 refactor turns   8
A3 repair turns     5
A3 repair attempts  1

Acceptance          12 / 12 required
```

Exact Docker image IDs, contract hashes, policy hashes, baseline Compose hashes,
Trivy-cache-manifest hash and Claude Code version are frozen by
`environment_lock_v2.json`.

## Output structure

Each official run produces, among other files:

```text
R0001_<architecture>/
├── run_config.json
├── workspace/
├── a1_iteration_01/
├── ...
├── a1_summary.json
├── analysis_before/
│   └── quality_before.json
├── analysis_before_v2/
│   ├── security_before.json
│   └── findings.json
├── a3/
│   ├── workspace/
│   ├── attempt_01/
│   ├── analysis_after/
│   ├── before_after.json
│   └── a3_summary.json
├── FINAL_SUMMARY.json
└── FINAL_REPORT.md
```

If A2+A4 produce zero findings, A3 is skipped and consumes zero Claude calls.

## Important

The previous `Pxxxx` directories are pilot evidence and must not be deleted or
renamed. Do not rerun them merely to make their invocation style uniform. The
new unified runner applies only to the official `Rxxxx` phase.


## v2 hardening after aborted R0001

R0001_monolith exposed an infrastructure preflight defect: Trivy database
files existed but their metadata files had been removed during Git cache
cleanup. v2 therefore verifies required cache files, hashes every cache file
against the frozen manifest, performs real network-disabled Trivy vulnerability
and secret/misconfiguration smoke scans before Claude can run, and freezes the
Python orchestrator, A4 runner and Graphify runtime hashes in the environment
lock. R0001 remains ABORTED_INFRASTRUCTURE and the paired primary series starts
with R0002.

## v2.1 Docker Desktop smoke-test fix

The Trivy offline smoke workspace is created under `<repo>/.experiment-runtime/`
instead of host `/tmp`. Docker Desktop on Linux may reject bind mounts from
`/tmp` when that path is not shared, while the repository under `/home/...` is
already available to Docker. The temporary child directory is removed
automatically after the smoke test.

This change affects only preflight infrastructure and does not call Claude.
