#!/usr/bin/env bash
# Agente 2 (revisao estatica) - roda PMD + SpotBugs sobre monolito e
# microservicos via plugins Maven, reaproveitando o cache ~/.m2 ja
# populado pelo Agente 4 (ver run_trivy.sh). Ver AGENTE2_ESPECIFICACAO.md
# para a justificativa de ferramentas/regras/versoes.
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
METRICS_DIR="$ROOT_DIR/metrics"
mkdir -p "$METRICS_DIR" "$HOME/.m2"

TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
MVN_IMAGE="maven:3.9-eclipse-temurin-21"
MVN_NET_OPTS="-Dmaven.wagon.http.retryHandler.count=3 -Dmaven.wagon.httpconnectionManager.ttlSeconds=120"

PMD_PLUGIN="org.apache.maven.plugins:maven-pmd-plugin:3.21.2:pmd"
SPOTBUGS_PLUGIN="com.github.spotbugs:spotbugs-maven-plugin:4.8.6.0:spotbugs"
PMD_RULESETS="category/java/bestpractices.xml,category/java/errorprone.xml,category/java/design.xml,category/java/multithreading.xml,category/java/performance.xml"

LOG_SUMMARY="$METRICS_DIR/agente2_resumo_${TIMESTAMP}.md"
{
  echo "# Agente 2 (revisao estatica) - PMD + SpotBugs"
  echo "Executado em: $(date -Iseconds)"
  echo
} > "$LOG_SUMMARY"

# $1 = nome do modulo (para nomear arquivos de saida)
# $2 = caminho absoluto do diretorio do modulo (contem pom.xml)
analyze_module() {
  local MODULE_NAME="$1"
  local MODULE_DIR="$2"

  if [ ! -f "$MODULE_DIR/pom.xml" ]; then
    echo "   (pulando $MODULE_NAME: sem pom.xml)"
    echo "- **$MODULE_NAME**: pulado (sem pom.xml)" >> "$LOG_SUMMARY"
    return 0
  fi

  echo "== Agente 2: $MODULE_NAME (PMD) =="
  if ! docker run --rm \
    -v "$MODULE_DIR:/app" \
    -v "$HOME/.m2:/root/.m2" \
    -w /app \
    "$MVN_IMAGE" \
    mvn -B -ntp -q $MVN_NET_OPTS "$PMD_PLUGIN" \
      -Dformat=xml -Drulesets="$PMD_RULESETS" -Dpmd.skip=false
  then
    echo "   AVISO: PMD falhou em $MODULE_NAME"
  fi

  if [ -f "$MODULE_DIR/target/pmd.xml" ]; then
    cp "$MODULE_DIR/target/pmd.xml" "$METRICS_DIR/agente2_${MODULE_NAME}_pmd_${TIMESTAMP}.xml"
    PMD_COUNT=$(grep -c '<violation ' "$MODULE_DIR/target/pmd.xml" 2>/dev/null || echo 0)
    echo "- **$MODULE_NAME** (PMD): $PMD_COUNT violacoes" >> "$LOG_SUMMARY"
  else
    echo "- **$MODULE_NAME** (PMD): relatorio nao gerado" >> "$LOG_SUMMARY"
  fi

  echo "== Agente 2: $MODULE_NAME (SpotBugs) =="
  if ! docker run --rm \
    -v "$MODULE_DIR:/app" \
    -v "$HOME/.m2:/root/.m2" \
    -w /app \
    "$MVN_IMAGE" \
    mvn -B -ntp -q $MVN_NET_OPTS compile "$SPOTBUGS_PLUGIN" \
      -Dspotbugs.effort=Max -Dspotbugs.threshold=Low \
      -Dspotbugs.xmlOutput=true -Dspotbugs.htmlOutput=true
  then
    echo "   AVISO: SpotBugs falhou em $MODULE_NAME"
  fi

  if [ -f "$MODULE_DIR/target/spotbugsXml.xml" ]; then
    cp "$MODULE_DIR/target/spotbugsXml.xml" "$METRICS_DIR/agente2_${MODULE_NAME}_spotbugs_${TIMESTAMP}.xml"
    [ -f "$MODULE_DIR/target/spotbugs.html" ] && \
      cp "$MODULE_DIR/target/spotbugs.html" "$METRICS_DIR/agente2_${MODULE_NAME}_spotbugs_${TIMESTAMP}.html"
    SB_COUNT=$(grep -c '<BugInstance ' "$MODULE_DIR/target/spotbugsXml.xml" 2>/dev/null || echo 0)
    echo "- **$MODULE_NAME** (SpotBugs): $SB_COUNT achados" >> "$LOG_SUMMARY"
  else
    echo "- **$MODULE_NAME** (SpotBugs): relatorio nao gerado" >> "$LOG_SUMMARY"
  fi

  echo >> "$LOG_SUMMARY"
}

echo "## Monolito" >> "$LOG_SUMMARY"
analyze_module "monolito" "$ROOT_DIR/multiagente/monolito"

echo "## Microservicos" >> "$LOG_SUMMARY"
for MODULE in api-gateway eureka-server market-service trade-service user-service; do
  analyze_module "$MODULE" "$ROOT_DIR/multiagente/microservicos/$MODULE"
done

echo "Resumo salvo em $LOG_SUMMARY"
echo "Relatorios detalhados (XML/HTML) salvos em $METRICS_DIR"
